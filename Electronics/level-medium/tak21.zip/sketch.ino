#include <DHT.h>

// -------------------- Pin Definitions --------------------
#define DHTPIN 4          // DHT22 Data Pin
#define DHTTYPE DHT22     // DHT22 Sensor Type

#define MQ135_PIN 34      // MQ-135 Analog Output
#define LED_PIN 2         // LED (Simulated Buzzer)

// -------------------- Sensor Setup --------------------
DHT dht(DHTPIN, DHTTYPE);

// -------------------- Thresholds --------------------
const int gasThreshold = 1800;     // Adjust if needed
const float humidityThreshold = 70.0;

void setup() {
  Serial.begin(115200);

  dht.begin();

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  Serial.println("====================================");
  Serial.println(" Air Quality Safety Monitor ");
  Serial.println(" ESP32 + MQ135 + DHT22 ");
  Serial.println("====================================");
}

void loop() {

  // Read DHT22 values
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  // Read MQ135 value
  int gasValue = analogRead(MQ135_PIN);

  // Check if DHT22 reading failed
  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT22!");
    delay(2000);
    return;
  }

  // Display Sensor Values
  Serial.println("------------------------------------");
  Serial.print("Temperature : ");
  Serial.print(temperature);
  Serial.println(" °C");

  Serial.print("Humidity    : ");
  Serial.print(humidity);
  Serial.println(" %");

  Serial.print("Gas Level   : ");
  Serial.println(gasValue);

  // Air Quality Check
  if (gasValue > gasThreshold && humidity > humidityThreshold) {

    digitalWrite(LED_PIN, HIGH);

    Serial.println();
    Serial.println("***** ALERT *****");
    Serial.println("Unsafe Air Quality!");
    Serial.println("High Gas Level Detected");
    Serial.println("Humidity Above 70%");
    Serial.println("LED (Buzzer) : ON");

  } else {

    digitalWrite(LED_PIN, LOW);

    Serial.println();
    Serial.println("Status : SAFE");
    Serial.println("LED (Buzzer) : OFF");
  }

  Serial.println();

  delay(2000);
}