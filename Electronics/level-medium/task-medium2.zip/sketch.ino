#define TRIG_PIN 23
#define ECHO_PIN 18
#define LDR_PIN 34      // AO pin of LDR Module
#define LED_PIN 4

long duration;
float distance;
int ldrValue;

void setup() {

  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(LED_PIN, OUTPUT);
}

void loop() {

  // Measure distance
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  duration = pulseIn(ECHO_PIN, HIGH);

  distance = duration * 0.0343 / 2;

  // Read LDR Module
  ldrValue = analogRead(LDR_PIN);

  Serial.print("Distance : ");
  Serial.print(distance);
  Serial.println(" cm");

  Serial.print("LDR Value : ");
  Serial.println(ldrValue);

  if (distance < 10) {

    digitalWrite(LED_PIN, HIGH);
    Serial.println("LED Status : SOLID ON");
    delay(200);

  }
  else if (distance < 20) {

    digitalWrite(LED_PIN, HIGH);
    delay(100);
    digitalWrite(LED_PIN, LOW);
    delay(100);

    Serial.println("LED Status : FAST BLINK");
  }
  else {

    // Use LDR to control LED ON/OFF
    if (ldrValue < 2000) {
      digitalWrite(LED_PIN, HIGH);
      Serial.println("LED Status : NORMAL (Dark)");
    } else {
      digitalWrite(LED_PIN, LOW);
      Serial.println("LED Status : NORMAL (Bright)");
    }

    delay(300);
  }

  Serial.println("--------------------------");
}